### Hexlet tests and linter status:
[![Actions Status](https://github.com/Difukulus/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Difukulus/python-project-50/actions)

asciinema gendiff:
<script src="https://asciinema.org/a/x4RjEGhwwnUU0wrXe4pp9FJZQ.js" id="asciicast-x4RjEGhwwnUU0wrXe4pp9FJZQ" async="true"></script>
